import { motion } from 'framer-motion';
import { Brain, Sparkles, Target, Clock, Trophy, BookOpen, MessageCircle } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'AI-Powered Tutoring',
    description: 'Get instant, personalized explanations on any topic. Our AI adapts to your learning style and pace.',
    gradient: 'from-purple-500 to-pink-500'
  },
  {
    icon: Target,
    title: 'Adaptive Quizzes',
    description: 'Smart quizzes that adjust difficulty based on your performance. Never too hard, never too easy.',
    gradient: 'from-pink-500 to-cyan-500'
  },
  {
    icon: Sparkles,
    title: 'Smart Study Plans',
    description: 'AI-generated study schedules that fit your goals and available time. Study efficiently, not endlessly.',
    gradient: 'from-cyan-500 to-purple-500'
  },
  {
    icon: MessageCircle,
    title: 'Natural Conversations',
    description: 'Chat naturally with your AI tutor. Ask questions, get clarifications, and learn through dialogue.',
    gradient: 'from-purple-500 to-cyan-500'
  },
  {
    icon: Clock,
    title: 'Progress Tracking',
    description: 'Detailed analytics show your growth over time. Celebrate milestones and identify areas to improve.',
    gradient: 'from-pink-500 to-purple-500'
  },
  {
    icon: Trophy,
    title: 'Gamified Learning',
    description: 'Earn points, badges, and compete with friends. Learning is more fun when it feels like a game.',
    gradient: 'from-cyan-500 to-pink-500'
  }
];

export default function Features() {
  return (
    <section id="features" className="relative py-24 sm:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-slate-950">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-purple-950/20 to-slate-950" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 sm:mb-20"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 mb-6">
            <BookOpen className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-medium text-purple-300">Powerful Features</span>
          </div>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6">
            Everything You Need to{' '}
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
              Excel
            </span>
          </h2>
          <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto">
            Powerful AI tools designed to transform how you learn, study, and achieve your academic goals.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="group relative p-6 sm:p-8 rounded-2xl bg-slate-900/50 border border-slate-800/50 hover:border-purple-500/30 transition-all duration-300"
            >
              {/* Gradient Glow */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
              
              {/* Icon */}
              <div className={`relative w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} p-3 mb-5 shadow-lg`}>
                <feature.icon className="w-full h-full text-white" />
              </div>

              {/* Content */}
              <h3 className="relative text-xl sm:text-2xl font-bold text-white mb-3">
                {feature.title}
              </h3>
              <p className="relative text-slate-400 leading-relaxed">
                {feature.description}
              </p>

              {/* Hover Arrow */}
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                whileHover={{ opacity: 1, x: 0 }}
                className="absolute bottom-6 right-6 text-purple-400"
              >
                →
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}