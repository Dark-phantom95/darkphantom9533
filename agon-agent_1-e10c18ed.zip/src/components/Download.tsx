import { motion } from 'framer-motion';
import { Download, Smartphone, Monitor, Apple, Play, Check, Star } from 'lucide-react';

const platforms = [
  {
    name: 'iOS',
    icon: Apple,
    description: 'iPhone & iPad',
    available: true,
    color: 'from-slate-400 to-slate-600'
  },
  {
    name: 'Android',
    icon: Smartphone,
    description: 'Phones & Tablets',
    available: true,
    color: 'from-green-400 to-emerald-600'
  },
  {
    name: 'Desktop',
    icon: Monitor,
    description: 'Mac & Windows',
    available: true,
    color: 'from-purple-400 to-pink-600'
  }
];

const reviews = [
  { name: 'Sarah M.', rating: 5, text: 'This app changed how I study. The AI tutor is incredible!' },
  { name: 'James K.', rating: 5, text: 'Best study app I have ever used. Highly recommend!' },
  { name: 'Emily R.', rating: 5, text: 'The adaptive quizzes are amazing. So personalized!' }
];

export default function DownloadSection() {
  const handleDownload = async (platform: string) => {
    try {
      await fetch('/api/downloads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform })
      });
    } catch (err) {
      console.error('Download tracking error:', err);
    }
  };

  return (
    <section id="download" className="relative py-24 sm:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-slate-950">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-purple-950/30 to-slate-950" />
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[1200px] h-[600px] bg-gradient-to-t from-purple-500/20 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 mb-6">
            <Download className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-medium text-purple-300">Get Started Free</span>
          </div>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6">
            Download{' '}
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
              NoteFusion. AI
            </span>
          </h2>
          <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto">
            Available on all your devices. Start learning smarter today.
          </p>
        </motion.div>

        {/* Platform Cards */}
        <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto mb-16">
          {platforms.map((platform, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5, scale: 1.02 }}
              className="relative p-6 rounded-2xl bg-slate-900/50 border border-slate-800/50 hover:border-purple-500/30 transition-all group cursor-pointer"
              onClick={() => handleDownload(platform.name)}
            >
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${platform.color} p-3 mb-4 shadow-lg group-hover:scale-110 transition-transform`}>
                <platform.icon className="w-full h-full text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-1">{platform.name}</h3>
              <p className="text-sm text-slate-400 mb-4">{platform.description}</p>
              <div className="flex items-center gap-2 text-sm text-green-400">
                <Check className="w-4 h-4" />
                Available Now
              </div>
            </motion.div>
          ))}
        </div>

        {/* Main Download CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative max-w-2xl mx-auto"
        >
          <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-purple-500/10 via-pink-500/10 to-cyan-500/10 border border-purple-500/20 backdrop-blur-sm">
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-2 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold text-white mb-2">
                Join 50,000+ Students
              </h3>
              <p className="text-slate-400">
                Start your journey to smarter learning today. It's free!
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(168, 85, 247, 0.4)' }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleDownload('iOS')}
                className="flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-slate-800 text-white font-semibold hover:bg-slate-700 transition-colors"
              >
                <Apple className="w-6 h-6" />
                <div className="text-left">
                  <div className="text-xs text-slate-400">Download on the</div>
                  <div className="text-lg">App Store</div>
                </div>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(168, 85, 247, 0.4)' }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleDownload('Android')}
                className="flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-slate-800 text-white font-semibold hover:bg-slate-700 transition-colors"
              >
                <Play className="w-6 h-6" />
                <div className="text-left">
                  <div className="text-xs text-slate-400">Get it on</div>
                  <div className="text-lg">Google Play</div>
                </div>
              </motion.button>
            </div>
          </div>
        </motion.div>

        {/* Reviews */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mt-16 grid sm:grid-cols-3 gap-4 max-w-4xl mx-auto"
        >
          {reviews.map((review, index) => (
            <div key={index} className="p-5 rounded-xl bg-slate-900/50 border border-slate-800/50">
              <div className="flex items-center gap-1 mb-2">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <p className="text-sm text-slate-300 mb-2">"{review.text}"</p>
              <p className="text-xs text-slate-500">— {review.name}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}