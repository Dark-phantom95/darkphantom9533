import { motion } from 'framer-motion';
import { Download, ExternalLink, Lock, Sparkles, X, Maximize2 } from 'lucide-react';
import { useState } from 'react';

export default function Demo() {
  const [showLimitModal, setShowLimitModal] = useState(false);
  const [usageCount, setUsageCount] = useState(0);

  const handleIframeClick = () => {
    if (usageCount >= 2) {
      setShowLimitModal(true);
    } else {
      setUsageCount(prev => prev + 1);
    }
  };

  return (
    <section id="demo" className="relative py-24 sm:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-slate-950">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-cyan-950/10 to-slate-950" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-purple-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 sm:mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-6">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-sm font-medium text-cyan-300">Try It Out</span>
          </div>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6">
            Experience{' '}
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
              NoteFusion. AI
            </span>
          </h2>
          <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto">
            Try our web demo below, but for the full experience with all features, download the app.
          </p>
        </motion.div>

        {/* Demo Container */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          {/* Browser Frame */}
          <div className="relative rounded-2xl overflow-hidden border border-slate-800/50 shadow-2xl shadow-purple-500/10">
            {/* Browser Header */}
            <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                  <div className="w-3 h-3 rounded-full bg-green-500/80" />
                </div>
                <div className="ml-4 px-4 py-1.5 rounded-lg bg-slate-800 text-sm text-slate-400 flex items-center gap-2">
                  <Lock className="w-3 h-3" />
                  neostudy-ai.designarena.ai
                </div>
              </div>
              <div className="flex items-center gap-2">
                <motion.a
                  href="https://neostudy-ai.designarena.ai"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.05 }}
                  className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <Maximize2 className="w-4 h-4" />
                </motion.a>
                <motion.a
                  href="https://neostudy-ai.designarena.ai"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.05 }}
                  className="p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </motion.a>
              </div>
            </div>

            {/* Iframe Container */}
            <div 
              className="relative aspect-[16/10] bg-slate-900"
              onClick={handleIframeClick}
            >
              <iframe
                src="https://neostudy-ai.designarena.ai"
                className="w-full h-full"
                title="NoteFusion. AI Demo"
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
              />
              
              {/* Usage Limit Overlay */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <div className="px-4 py-2 rounded-lg bg-slate-900/90 backdrop-blur-sm border border-slate-700 text-sm text-slate-400">
                  <span className="text-cyan-400 font-medium">Web Demo</span> — Limited features
                </div>
                <motion.a
                  href="#download"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-purple-500 to-cyan-500 text-white font-medium text-sm shadow-lg"
                >
                  <Download className="w-4 h-4" />
                  Get Full App
                </motion.a>
              </div>
            </div>
          </div>

          {/* Floating Download Prompt */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="absolute -right-4 top-1/2 -translate-y-1/2 hidden xl:block"
          >
            <div className="p-4 rounded-xl bg-gradient-to-br from-purple-500/10 to-cyan-500/10 border border-purple-500/20 backdrop-blur-sm max-w-[200px]">
              <p className="text-sm text-slate-300 mb-3">Want the full experience?</p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-purple-500 to-cyan-500 text-white font-medium text-sm"
              >
                <Download className="w-4 h-4" />
                Download App
              </motion.button>
            </div>
          </motion.div>
        </motion.div>

        {/* Feature Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mt-12 grid sm:grid-cols-2 gap-4 max-w-3xl mx-auto"
        >
          <div className="p-5 rounded-xl bg-slate-900/50 border border-slate-800/50">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 rounded-full bg-slate-500" />
              <span className="font-semibold text-slate-300">Web Demo</span>
            </div>
            <ul className="space-y-2 text-sm text-slate-500">
              <li>• Limited AI interactions</li>
              <li>• Basic features only</li>
              <li>• No offline access</li>
              <li>• No progress saving</li>
            </ul>
          </div>
          <div className="p-5 rounded-xl bg-gradient-to-br from-purple-500/10 to-cyan-500/10 border border-purple-500/20">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 rounded-full bg-gradient-to-r from-purple-500 to-cyan-500" />
              <span className="font-semibold text-white">Full App</span>
            </div>
            <ul className="space-y-2 text-sm text-slate-300">
              <li>• Unlimited AI tutoring</li>
              <li>• All premium features</li>
              <li>• Offline mode</li>
              <li>• Cloud sync & progress</li>
            </ul>
          </div>
        </motion.div>
      </div>

      {/* Limit Modal */}
      {showLimitModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          onClick={() => setShowLimitModal(false)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={e => e.stopPropagation()}
            className="relative max-w-md w-full p-8 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl"
          >
            <button
              onClick={() => setShowLimitModal(false)}
              className="absolute top-4 right-4 p-2 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="text-center mb-6">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
                <Lock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Web Demo Limit Reached</h3>
              <p className="text-slate-400">Download the full app for unlimited access to all features.</p>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500 text-white font-bold text-lg shadow-lg shadow-purple-500/30"
            >
              <Download className="w-5 h-5" />
              Download Free App
            </motion.button>
          </motion.div>
        </motion.div>
      )}
    </section>
  );
}